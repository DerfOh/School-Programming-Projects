//
//  Vehicle.cpp
//  labProb4-Pg656.cpp
//
//  Created by Fredrick Paulin on 11/11/13.
//  Copyright (c) 2013 Fredrick Paulin. All rights reserved.
//

#include "Vehicle.h"
