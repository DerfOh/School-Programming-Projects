//
//  ComputerPlayer.h
//  Programming_Assignment_7
//
//  Created by Fredrick Paulin on 11/20/13.
//  Copyright (c) 2013 Fredrick Paulin. All rights reserved.
//

#ifndef __Programming_Assignment_7__ComputerPlayer__
#define __Programming_Assignment_7__ComputerPlayer__

#include <iostream>
#include "Player.h"

class ComputerPlayer : public Player
{
public:
    int getGuess();
    
protected:
    
private:
    
};

#endif /* defined(__Programming_Assignment_7__ComputerPlayer__) */
