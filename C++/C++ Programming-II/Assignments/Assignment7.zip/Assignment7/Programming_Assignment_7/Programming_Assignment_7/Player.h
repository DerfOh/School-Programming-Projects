//
//  Player.h
//  Programming_Assignment_7
//
//  Created by Fredrick Paulin on 11/20/13.
//  Copyright (c) 2013 Fredrick Paulin. All rights reserved.
//

#ifndef __Programming_Assignment_7__Player__
#define __Programming_Assignment_7__Player__

#include <iostream>
using namespace std;

class Player
{
public:
    virtual int getGuess() = 0;
    //Player();
    /*
    virtual int getGuess()
    {
        cout <<"[NO FUNCTION ASSIGNED]";
        return 0;
    }
    */
protected:
    
private:
    
    
};

#endif /* defined(__Programming_Assignment_7__Player__) */
