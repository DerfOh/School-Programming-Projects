#ifndef USER_H
#define USER_H
#include "Security.h"



class User
{
    public:
        User(string usernameIn, string passwordIn);
        bool login();

    protected:
    private:
        string username, password;
};

#endif // USER_H
