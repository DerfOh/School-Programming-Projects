#include "User.h"
#include "Security.h"
#include <iostream>

using namespace std;

User::User(string usernameIn, string passwordIn) : username(usernameIn), password(passwordIn)
{
    //ctor
}

bool User::login()
{
    if ((username=="abbott") && (password=="monday")) return true;
    return (0);
}

