#include <iostream>

using namespace std;

#include "Security.h"
#include "Administrator.h"
#include "User.h"

int main()
{
    Administrator a1("costello", "tuesday");
    User u1("abbott", "monday");

    cout << a1.login() << " " << u1.login();


}
