#include <iostream>
#include "Ninja.h"

using namespace std;

Ninja::Ninja()
{
    //ctor
}

Ninja::~Ninja()
{
    //dtor
}

void Ninja::Attack()
{
    cout << "Hiyaa!" <<endl;
}
