#include "Enemy.h"

Enemy::Enemy()
{
    //ctor
}

Enemy::~Enemy()
{
    //dtor
}

void Enemy::Attack()
        {
            cout << "[NO ATTACK POWER!]" << endl;
        }
