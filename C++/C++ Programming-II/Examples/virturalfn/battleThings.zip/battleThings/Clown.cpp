#include <iostream>
#include "Clown.h"


using namespace std;

Clown::Clown()
{
    //ctor
}

Clown::~Clown()
{
    //dtor
}

void Clown::Attack()
{
    cout << "HonkHonk" << endl;
}
