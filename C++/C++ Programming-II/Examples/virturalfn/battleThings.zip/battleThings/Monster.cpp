#include <iostream>
#include "Monster.h"

using namespace std;

Monster::Monster()
{
    //ctor
}

Monster::~Monster()
{
    //dtor
}

void Monster::Attack()
{
    cout << "ROOOAAWWRRRR!!!" << endl;
}
