/* Author: 
 * Code function:  
 * Class: Problem Solving and Programming with Java - CSC 276
 */
public class Deposit extends MonetaryTransaction {

	public Deposit(double amt)
	{
		amount = amt;
	}
}
